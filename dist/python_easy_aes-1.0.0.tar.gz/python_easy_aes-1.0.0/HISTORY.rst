=======
History
=======

0.0.0 (2022-06-01)
------------------

* First release on PyPI.
